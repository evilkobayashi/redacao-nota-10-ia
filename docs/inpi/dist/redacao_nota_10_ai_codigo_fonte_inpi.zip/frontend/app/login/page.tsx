'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { PenTool, Mail, Lock, ArrowLeft, Eye, EyeOff } from 'lucide-react'
import { createClient } from '@/utils/supabase/client'

export default function LoginPage() {
  const router = useRouter()
  const supabase = createClient()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [checkingAuth, setCheckingAuth] = useState(true)
  const [message, setMessage] = useState({ text: '', type: '' })

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) {
        router.replace('/dashboard')
      } else {
        setCheckingAuth(false)
      }
    }).catch(() => {
      setCheckingAuth(false)
    })
  }, [router, supabase])

  async function handleGoogleSignIn() {
    setLoading(true)
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      }
    })
    if (error) {
      setMessage({ text: error.message, type: 'error' })
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setMessage({ text: '', type: '' })
    
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    
    if (error) {
      setMessage({ text: error.message, type: 'error' })
      setLoading(false)
    } else {
      router.push('/dashboard')
    }
  }

  if (checkingAuth) {
    return (
      <div className="min-h-screen grid place-items-center bg-white">
        <div className="w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-12 bg-white font-sans text-gray-900 overflow-x-hidden">
      
      {/* LEFT — Showcase Panel */}
      <div className="hidden lg:flex lg:col-span-6 relative bg-gradient-to-br from-red-900 via-red-950 to-zinc-950 p-12 flex-col justify-between overflow-hidden border-r border-red-900/50">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-red-500/20 blur-[100px] rounded-full pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-amber-500/15 blur-[100px] rounded-full pointer-events-none" />

        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-red-500 to-amber-400 rounded-xl flex items-center justify-center shadow-lg">
            <PenTool className="w-5 h-5 text-white" />
          </div>
          <span className="font-extrabold text-white text-2xl tracking-tight">
            Redação <span className="text-red-400">Nota 10</span> <span className="text-amber-400">AÍ</span>
          </span>
        </div>

        <div className="relative z-10 space-y-6 my-auto max-w-lg">
          <span className="inline-flex items-center gap-2 bg-red-500/20 text-red-300 border border-red-400/30 text-xs font-extrabold px-3.5 py-1.5 rounded-full uppercase tracking-wider">
            Correção ENEM com IA
          </span>
          <h2 className="text-4xl lg:text-5xl font-black text-white leading-tight">
            Descubra sua nota antes da prova.
          </h2>
          <p className="text-gray-300 text-base leading-relaxed">
            A única IA treinada nos manuais oficiais do INEP. Feedback real nas 5 competências em menos de 30 segundos.
          </p>
        </div>

        <div className="relative z-10 text-xs text-gray-400 pt-6 border-t border-white/10">
          © {new Date().getFullYear()} AÍ Tecnologia e Educação Ltda.
        </div>
      </div>

      {/* RIGHT — Login Form */}
      <div className="lg:col-span-6 flex flex-col justify-between p-6 sm:p-12">
        <div className="flex items-center justify-between mb-8">
          <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-gray-500 hover:text-gray-900 transition-colors">
            <ArrowLeft className="w-4 h-4" /> Voltar
          </Link>
        </div>

        <div className="w-full max-w-md mx-auto my-auto py-6">
          <div className="text-center mb-8">
            <div className="lg:hidden inline-flex w-12 h-12 bg-gradient-to-tr from-red-600 to-amber-500 rounded-xl items-center justify-center shadow-lg mb-4">
              <PenTool className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-extrabold text-gray-950 tracking-tight">Bem-vindo de volta</h1>
            <p className="text-sm text-gray-500 mt-2">Entre para continuar corrigindo suas redações.</p>
          </div>

          <div className="bg-white border border-gray-200 rounded-3xl p-8 shadow-xl">
            {/* Google */}
            <button onClick={handleGoogleSignIn} disabled={loading}
              className="w-full h-12 rounded-xl bg-white border border-gray-200 hover:bg-gray-50 text-gray-800 font-bold text-sm flex items-center justify-center gap-3 shadow-sm transition-all cursor-pointer mb-4">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              Continuar com Google
            </button>

            <div className="relative flex items-center justify-center my-4">
              <div className="w-full border-t border-gray-200" />
              <span className="absolute bg-white px-3 text-xs text-gray-400 font-semibold uppercase">ou</span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-gray-700 uppercase tracking-wider ml-1">E-mail</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400" />
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
                    className="w-full pl-11 h-12 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 focus:ring-2 focus:ring-red-500 text-sm font-medium outline-none transition-all"
                    placeholder="seu@email.com" />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-gray-700 uppercase tracking-wider ml-1">Senha</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400" />
                  <input type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-11 pr-11 h-12 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 focus:ring-2 focus:ring-red-500 text-sm font-medium outline-none transition-all"
                    placeholder="••••••••" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-3.5 text-gray-400 hover:text-gray-600">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {message.text && (
                <p className={`text-sm text-center ${message.type === 'error' ? 'text-red-500' : 'text-blue-500'}`}>{message.text}</p>
              )}

              <button type="submit" disabled={loading}
                className="w-full h-12 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-md transition-all">
                {loading ? 'Entrando...' : 'Entrar'}
              </button>
            </form>

            <p className="text-center text-sm text-gray-500 mt-6">
              Não tem conta?{' '}
              <Link href="/signup" className="font-bold text-red-600 hover:underline">Criar conta grátis</Link>
            </p>
          </div>
        </div>

        <div />
      </div>
    </div>
  )
}
